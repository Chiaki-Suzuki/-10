let banner  = {
  template: `
  <section id="section_8" class="section_8">
  <div class="inner">
      <div class="link_bt_area">
          <!-- <p class="link_title">相続関連業務・投資信託<br>専用ホームページ</p> -->
          <p class="link_bt"><a href="http://souzoku.legal-contact.com">詳しくはこちら</a></p>
      </div>
  </div>
  </section>
  `
}
