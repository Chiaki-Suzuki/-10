let topnav = {
  template: `
  <section class="nav_area">
    <ul class="nav_pc pc_only">
      <li class="rink_btn"><a href="#section_1">当事務所について</a></li>
      <li class="rink_btn"><a href="#section_2">経営理念</a></li>
      <li class="rink_btn"><a href="#section_3">代表挨拶</a></li>
      <li class="rink_btn"><a href="#section_4">業務内容</a></li>
      <li class="rink_btn"><a href="#section_5">ご依頼の流れ</a></li>
      <li class="rink_btn"><a href="#section_7">事務所概要</a></li>
      <li class="rink_btn"><a href="#section_6">アクセス</a></li>
    </ul>
  </section>
  `
}
